{ version: "0.6.0",  // Figma plugin API version
  name: "figplug example: ui-ts-html",
  id: "YOUR_ID_HERE",
  script: "plugin.ts",
  ui: "ui.html",
}
