Example of a simple plugin written in TypeScript with a HTML-only UI
