{ version: "0.6.0",  // Figma plugin API version
  name: "figplug example: ui-ts",
  id: "YOUR_ID_HERE",
  script: "plugin.ts",
  ui: "ui.ts",
}
