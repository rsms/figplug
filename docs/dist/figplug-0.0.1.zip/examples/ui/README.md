Example of a simple plugin with UI written in TypeScript with HTML and CSS
