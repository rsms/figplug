{ version: "0.6.0",
  name: "figplug example: manifest-build",
  script: "plugin.ts",
  build: "../../bin/figplug -o=. src",
}