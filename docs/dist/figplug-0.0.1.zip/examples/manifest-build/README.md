This demonstrates making use of the `build` property of manifest.json
which makes Figma run figplug automatically.

Build with `figplug -o=. src`
