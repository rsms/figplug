Example of a simple plugin written in TypeScript
