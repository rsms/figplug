{ version: "0.6.0",  // Figma plugin API version
  name: "figplug example: basic",
  id: "YOUR_ID_HERE",
  script: "plugin.ts",
}
